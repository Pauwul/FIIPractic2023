type AutoCompleteOption = {
  value: string;
};

export default AutoCompleteOption;
