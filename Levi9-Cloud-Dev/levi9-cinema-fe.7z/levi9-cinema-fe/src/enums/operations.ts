enum Operations {
  Add,
  Update,
}

export default Operations;
