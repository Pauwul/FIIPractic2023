enum MovieState {
  None,
  Seen,
  Wishlist,
}

export default MovieState;
